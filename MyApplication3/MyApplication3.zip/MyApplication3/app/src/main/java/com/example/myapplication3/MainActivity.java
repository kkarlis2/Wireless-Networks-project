package com.example.myapplication3;

import android.widget.ImageView;
import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;
import android.os.Environment;
import android.Manifest;


import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.content.pm.PackageManager;
import android.widget.Button;
import android.widget.Toast;
import android.view.View;



public class MainActivity extends Activity {
    private ServerSocket serverSocket;
    private TextView textView;
    private final int READ_EXTERNAL_STORAGE_REQUEST = 1;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //add images and text to the app
        setContentView(R.layout.activity_main);
        ImageView imgview=(ImageView)findViewById(R.id.imageView);
        imgview.setBackgroundResource(R.drawable.wn);
        textView = (TextView) findViewById(R.id.ipadd);
        //buttons for start and stop server
        Button btn = findViewById(R.id.button);
        Button btn2 = findViewById(R.id.button2);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                new SocketServerThread().execute();
                textView.setText("Server started...");
            }

        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                finish();
            }

        });

        /*if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, READ_EXTERNAL_STORAGE_REQUEST);
        }else{
            //permission already granted
            //start the file sending task
            new SocketServerThread().execute();
            textView.setText("Sending files...");
        }


        new SocketServerThread().execute();*/
    }


   /* @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case READ_EXTERNAL_STORAGE_REQUEST:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted
                    //start the file sending task
                    new SocketServerThread().execute();
                } else {
                    // permission was denied
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
*/

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (serverSocket != null) {
            try {
                serverSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private class SocketServerThread extends AsyncTask<Void, String, Void> {
        static final int SocketServerPORT = 12345;

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                //Establish the listen socket
                serverSocket = new ServerSocket(SocketServerPORT);

                while (true) {
                    Socket socket = serverSocket.accept();
                    Thread thread = new Thread(new ClientHandler(socket));
                    thread.start();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

    }

    private class ClientHandler implements Runnable {
        private Socket socket;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        public void run() {
            try {
                // Create a BufferedReader to read from the socket
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                // Read the file name from the socket
                String fileName = in.readLine();
                // Get the downloads directory
                File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + File.separator + fileName);
                // Check if the file exists
                if (file.exists()) {
                    // Send the file to the client
                    try {
                        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
                        OutputStream os = socket.getOutputStream();
                        byte[] contents;
                        long fileLength = file.length();
                        long current = 0;
                        while(current!=fileLength){
                            int size=10000;
                            if(fileLength - current >= size)
                                current += size;
                            else{
                                size = (int)(fileLength - current);
                                current = fileLength;
                            }
                            contents = new byte[size];
                            bis.read(contents, 0, size);
                            os.write(contents);
                        }
                        os.flush();
                        // Close the file

                        bis.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                        //textView.setText("Error reading file:" + e.getMessage());
                    }



                } else {
                    // Send an error message to the client
                    PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                    out.println("Error: File not found");
                }

                // Close the socket
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}